﻿namespace LINQTestIUD
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.add = new System.Windows.Forms.Button();
            this.pname = new System.Windows.Forms.TextBox();
            this.prate = new System.Windows.Forms.TextBox();
            this.pcategories = new System.Windows.Forms.TextBox();
            this.pquntity = new System.Windows.Forms.TextBox();
            this.delete = new System.Windows.Forms.Button();
            this.update = new System.Windows.Forms.Button();
            this.pid = new System.Windows.Forms.TextBox();
            this.categoriesBox = new System.Windows.Forms.ComboBox();
            this.groDatabaseDataSet = new LINQTestIUD.GroDatabaseDataSet();
            this.groDatabaseDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.categoriesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.categoriesTableAdapter = new LINQTestIUD.GroDatabaseDataSetTableAdapters.CategoriesTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groDatabaseDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groDatabaseDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoriesBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(21, 23);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(767, 150);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // add
            // 
            this.add.Location = new System.Drawing.Point(175, 299);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(77, 27);
            this.add.TabIndex = 1;
            this.add.Text = "ADD";
            this.add.UseVisualStyleBackColor = true;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // pname
            // 
            this.pname.Location = new System.Drawing.Point(23, 200);
            this.pname.Name = "pname";
            this.pname.Size = new System.Drawing.Size(100, 20);
            this.pname.TabIndex = 2;
            this.pname.Text = "ProductName";
            // 
            // prate
            // 
            this.prate.Location = new System.Drawing.Point(175, 200);
            this.prate.Name = "prate";
            this.prate.Size = new System.Drawing.Size(100, 20);
            this.prate.TabIndex = 3;
            this.prate.Text = "ProductRate";
            // 
            // pcategories
            // 
            this.pcategories.Location = new System.Drawing.Point(344, 200);
            this.pcategories.Name = "pcategories";
            this.pcategories.Size = new System.Drawing.Size(100, 20);
            this.pcategories.TabIndex = 4;
            this.pcategories.Text = "ProductCategories";
            this.pcategories.TextChanged += new System.EventHandler(this.pcategories_TextChanged);
            // 
            // pquntity
            // 
            this.pquntity.Location = new System.Drawing.Point(521, 200);
            this.pquntity.Name = "pquntity";
            this.pquntity.Size = new System.Drawing.Size(100, 20);
            this.pquntity.TabIndex = 5;
            this.pquntity.Text = "ProductQuntity";
            // 
            // delete
            // 
            this.delete.Location = new System.Drawing.Point(508, 299);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(75, 27);
            this.delete.TabIndex = 6;
            this.delete.Text = "DELETE";
            this.delete.UseVisualStyleBackColor = true;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // update
            // 
            this.update.Location = new System.Drawing.Point(344, 299);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(75, 27);
            this.update.TabIndex = 7;
            this.update.Text = "UPDATA";
            this.update.UseVisualStyleBackColor = true;
            this.update.Click += new System.EventHandler(this.button1_Click);
            // 
            // pid
            // 
            this.pid.Location = new System.Drawing.Point(688, 200);
            this.pid.Name = "pid";
            this.pid.Size = new System.Drawing.Size(100, 20);
            this.pid.TabIndex = 8;
            this.pid.TextChanged += new System.EventHandler(this.pid_TextChanged);
            // 
            // categoriesBox
            // 
            this.categoriesBox.DataSource = this.categoriesBindingSource;
            this.categoriesBox.DisplayMember = "Categories_name";
            this.categoriesBox.FormattingEnabled = true;
            this.categoriesBox.Location = new System.Drawing.Point(643, 299);
            this.categoriesBox.Name = "categoriesBox";
            this.categoriesBox.Size = new System.Drawing.Size(121, 21);
            this.categoriesBox.TabIndex = 9;
            this.categoriesBox.ValueMember = "Categories_Id";
            this.categoriesBox.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // groDatabaseDataSet
            // 
            this.groDatabaseDataSet.DataSetName = "GroDatabaseDataSet";
            this.groDatabaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // groDatabaseDataSetBindingSource
            // 
            this.groDatabaseDataSetBindingSource.DataSource = this.groDatabaseDataSet;
            this.groDatabaseDataSetBindingSource.Position = 0;
            // 
            // categoriesBindingSource
            // 
            this.categoriesBindingSource.DataMember = "Categories";
            this.categoriesBindingSource.DataSource = this.groDatabaseDataSetBindingSource;
            // 
            // categoriesTableAdapter
            // 
            this.categoriesTableAdapter.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.categoriesBox);
            this.Controls.Add(this.pid);
            this.Controls.Add(this.update);
            this.Controls.Add(this.delete);
            this.Controls.Add(this.pquntity);
            this.Controls.Add(this.pcategories);
            this.Controls.Add(this.prate);
            this.Controls.Add(this.pname);
            this.Controls.Add(this.add);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groDatabaseDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groDatabaseDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoriesBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.TextBox pname;
        private System.Windows.Forms.TextBox prate;
        private System.Windows.Forms.TextBox pcategories;
        private System.Windows.Forms.TextBox pquntity;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.TextBox pid;
        private System.Windows.Forms.ComboBox categoriesBox;
        private System.Windows.Forms.BindingSource groDatabaseDataSetBindingSource;
        private GroDatabaseDataSet groDatabaseDataSet;
        private System.Windows.Forms.BindingSource categoriesBindingSource;
        private GroDatabaseDataSetTableAdapters.CategoriesTableAdapter categoriesTableAdapter;
    }
}

