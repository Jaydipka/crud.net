﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LINQTestIUD
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        GroDatabaseEntities groDatabaseEntities = new GroDatabaseEntities();

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            pid.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            pname.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            prate.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            pcategories.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            pquntity.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'groDatabaseDataSet.Categories' table. You can move, or remove it, as needed.
            this.categoriesTableAdapter.Fill(this.groDatabaseDataSet.Categories);
            showdata();
        }

        private void add_Click(object sender, EventArgs e)
        {
            GroProduct groProduct = new GroProduct();
            groProduct.ProductName = pname.Text;
            groProduct.ProductRate = Convert.ToInt32(prate.Text);
            groProduct.ProductQuntity = Convert.ToInt32(pquntity.Text);
            groProduct.ProductCategories =Convert.ToInt32(categoriesBox.SelectedValue);

            groDatabaseEntities.GroProducts.Add(groProduct);
            groDatabaseEntities.SaveChanges();

            showdata();
           
        }
        public void showdata()
        {
            dataGridView1.DataSource = groDatabaseEntities.GroProducts.ToList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int groId = Convert.ToInt32(pid.Text);

            GroProduct groProduct = groDatabaseEntities.GroProducts.Find(groId);
            groProduct.ProductName = pname.Text;
            groProduct.ProductRate =Convert.ToInt32(prate.Text);
            groProduct.ProductCategories = Convert.ToInt32(categoriesBox.SelectedValue);
            groProduct.ProductQuntity =Convert.ToInt32(pquntity.Text);

            groDatabaseEntities.SaveChanges();
            showdata();

        }

        private void delete_Click(object sender, EventArgs e)
        {
            int groId = Convert.ToInt32(pid.Text);

            GroProduct groProduct = groDatabaseEntities.GroProducts.Find(groId);
            groDatabaseEntities.GroProducts.Remove(groProduct);
            groDatabaseEntities.SaveChanges();
            showdata();
        }

        private void pid_TextChanged(object sender, EventArgs e)
        {

        }

        private void pcategories_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
